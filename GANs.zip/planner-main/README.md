# informal-planner-planning
voxelise image
