using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public enum BlockState { Valid = 0, Intersecting = 1, OutOfBounds = 1, Placed = 2 }
public class Block 
{
    public List<Voxel> Voxels;

    public Pattern BlockPattern;
    private VoxelGrid _grid;
    private GameObject _goBlock;

    public Vector3Int Anchor;
    public Quaternion Rotation;
    private bool _placed = false;


    //01 define block

    /// <summary>
    /// Get the current state of the block. Can be Valid, Intersecting, OutOfBound or Placed
    /// </summary>
    public BlockState State
    {
        get
        {
            if (_placed) return BlockState.Placed;
            if (Voxels.Count < BlockPattern.Indices.Count) return BlockState.OutOfBounds;

            //LJW out of bounds

            //if (Voxels.Count(v => v.Status != VoxelState.Alive) > 0) return BlockState.OutOfBounds;
            //LJW inter dead
            //if (Voxels.Count(v => v.Status == VoxelState.Occupied) > 0) return BlockState.Intersecting;
            return BlockState.Valid;
        }
    }

    public void CreateGOBlock()
    {
        _goBlock = GameObject.Instantiate(_grid.GOPatternPrefabs[BlockPattern], _grid.GetVoxelByIndex(Anchor).Centre, Rotation);
    }

    public bool ActivateVoxels()
    {
        if (State != BlockState.Valid)
        {
            Debug.LogWarning("Block can't be placed");
            return false;
        }
        //LJW COLOR

        Color randomCol = new Color(125,125,125);

        foreach (var voxel in Voxels)
        {
            voxel.Status = VoxelState.Occupied;
            //voxel._voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");
            voxel.VoxelGO.GetComponent<MeshRenderer>().enabled = false;
            voxel.SetColor(randomCol);
        }
        Debug.LogWarning("goblock");
        CreateGOBlock();
        _placed = true;
        return true;
    }


    public void PositionPattern()
    {
        Voxels = new List<Voxel>();
        foreach (var index in BlockPattern.Indices)
        {
            if (Util.TryOrientIndex(index, Anchor, Rotation, _grid, out var newIndex))
            {
                Voxels.Add(_grid.Voxels[newIndex.x, newIndex.y, newIndex.z]);
            }
        }
    }

    public Block(Pattern type, Vector3Int anchor, Quaternion rotation, VoxelGrid grid)
    {
        BlockPattern = type;
        Anchor = anchor;
        Rotation = rotation;
        _grid = grid;


        PositionPattern();
    }

    public Block(Block block, VoxelGrid grid)
    {
        BlockPattern = block.BlockPattern;
        Anchor = block.Anchor;
        Rotation = block.Rotation;
        _grid = grid;


        PositionPattern();
    }


    public int VoxelStatusAmount(VoxelState state)
    {
        return Voxels.Count(v => v.Status == state);
    }

    public void DeactivateVoxels()
    {
        foreach (var voxel in Voxels)
            voxel.Status = VoxelState.Available;
    }

    public void DestroyBlock()
    {
        DeactivateVoxels();
        if (_goBlock != null) GameObject.Destroy(_goBlock);
    }

    public Block CopyBlock()
    {
        Block copy = new Block(BlockPattern, Anchor, Rotation, _grid);

        return copy;
    }
}
