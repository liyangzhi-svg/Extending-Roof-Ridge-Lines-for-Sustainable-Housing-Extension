using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatternPosition
{
    public List<Vector3Int> Positions = new List<Vector3Int>();
    public List<Pattern> PossiblePatterns = new List<Pattern>();
    public List<Quaternion> Rotation = new List<Quaternion>();

    public PatternPosition(List<Vector3Int> positions, List<Pattern> possiblePatterns, List<Quaternion> rotation)
    {
        Positions = positions;
        PossiblePatterns = possiblePatterns;
        Rotation = rotation;
    }

    //public PatternPosition GetRotatedPatternPosition(Quaternion rotation, List<Pattern> patterns)
    //{
    //    List<Vector3Int> newPostions = new List<Vector3Int>(Positions);
    //    foreach (var position in newPostions)
    //    {
    //        Util.OrientIndex(position, Vector3Int.zero, rotation);
    //    }

    //    return new PatternPosition(newPostions, patterns);
    //}
}
