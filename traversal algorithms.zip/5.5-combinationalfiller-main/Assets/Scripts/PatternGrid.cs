using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class PatternGrid

{


    //public Vector3Int GridSize;
    //public Voxel[,,] Voxels;
    //public Corner[,,] Corners;
    //public Face[][,,] Faces = new Face[3][,,];
    //public Edge[][,,] Edges = new Edge[3][,,];
    //public Vector3 Origin;
    //public Vector3 Corner;
    //public float VoxelSize { get; private set; }
    //public PatternGrid(Vector3Int size, Vector3 origin, float voxelSize)
    //{
    //    GridSize = size;
    //    Origin = origin;
    //    VoxelSize = voxelSize;

    //    Voxels = new Voxel[GridSize.x, GridSize.y, GridSize.z];

    //    for (int x = 0; x < 5; x++)
    //    {
    //        for (int y = 0; y < 5; y++)
    //        {
    //            for (int z = 0; z < 5; z++)
    //            {
    //                Voxels[x, y, z] = new Voxel(
    //                    new Vector3Int(x, y, z),
    //                    this,
    //                    0.96f);
    //            }
    //        }
    //    }

    //}


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


}
