﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
/*
public class EnvironmentManager : MonoBehaviour
{
    #region Private fields

    VoxelGrid _voxelGrid;

    // Create image variable--- FROM David RC4_M1_C3
    Texture2D _sourceImage;


    //LJW 运行开关
    private VoxelGrid _grid;

    #endregion

    #region Unity methods

    public void Start()
    {

        // Read Image from resources--- FROM David RC4_M1_C3
        _sourceImage = Resources.Load<Texture2D>("Data/roof");

        // Create grid from image--- FROM David RC4_M1_C3
        _voxelGrid = new VoxelGrid(_sourceImage, 23, transform.position, 1f);


    }

 


    #endregion

    #region Public methods

    // Create public method to read image from button--- FROM David RC4_M1_C3
    /// <summary>
    /// Read the image and set the states of the Voxels
    /// </summary>
    public void ReadImage()
    {
        _voxelGrid.SetStatesFromImage(_sourceImage);
    }


    public void PlaceFloor()
    {
        _voxelGrid.SetStatesFromImage(_sourceImage);
    }
    #endregion

    #region Private methods


    #endregion
}
*/