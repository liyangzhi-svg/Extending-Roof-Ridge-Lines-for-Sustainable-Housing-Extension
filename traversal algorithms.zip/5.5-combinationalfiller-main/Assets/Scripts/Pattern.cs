using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using UnityEngine;


/// <summary>
/// The pattern that defines a block. Object of this class should only be made in the PatternManager
/// </summary>
public class Pattern
{
    /// <summary>
    /// The patterns are saved as ReadOnlyCollections rather than list so that once defined, the pattern can never be changed
    /// </summary>
    public ReadOnlyCollection<Vector3Int> Indices { get; }


    /// <summary>
    /// Pattern constructor. The indices will be stored in a ReadOnlyCollection
    /// </summary>
    ///<param name = "indices" > List of indices that define the patter.The indices should always relate to Vector3In(0,0,0) as anchor point</param>
    /// <param name="type">The PatternType of this pattern to add. Each type can only exist once</param>
    public Pattern(List<Vector3Int> indices)
    {
        Indices = new ReadOnlyCollection<Vector3Int>(indices);
    }

    public Pattern GetRotatedPattern(Quaternion rotation)
    {
        List<Vector3Int> newIndices = new List<Vector3Int>(Indices);
        foreach (var index in newIndices)
        {
            Util.OrientIndex(index, GetCentreOfPattern(), rotation);

        }

        return new Pattern(newIndices);
    }

    public Vector3 GetCentreOfPattern()
    {
        int minX = Indices.Min(i => i.x);
        int minY = Indices.Min(i => i.y);
        int minZ = Indices.Min(i => i.z);
        int maxX = Indices.Max(i => i.x);
        int maxY = Indices.Max(i => i.y);
        int maxZ = Indices.Max(i => i.z);

        return (new Vector3Int(maxX, maxY, maxZ) - new Vector3Int(minX, minX, minZ));
    }


    public override bool Equals(object other)
    {
        if (other == null || !this.GetType().Equals(other.GetType())) return false;
        Pattern otherPattern = (Pattern)other;
        if (otherPattern.Indices.Count != Indices.Count) return false;
        foreach (var index in Indices)
        {
            if (!otherPattern.Indices.Contains(index)) return false;
        }

        return true;

    }


    public override int GetHashCode()
    {
        return -131595806 + EqualityComparer<ReadOnlyCollection<Vector3Int>>.Default.GetHashCode(Indices);
    }
}

