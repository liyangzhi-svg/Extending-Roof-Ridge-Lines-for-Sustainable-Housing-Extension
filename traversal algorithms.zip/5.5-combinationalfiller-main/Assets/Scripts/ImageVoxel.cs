﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Create GraphVoxel, inherit from Voxel --- FROM David RC4_M1_C3
public class ImageVoxel : Voxel
{
    // Create Regions --- FROM David RC4_M1_C3
    #region Private fields

    // Create private _state float --- FROM David RC4_M1_C3
    private float _state;

    #endregion

    #region Public fields

    // Create Isactive variable --- FROM David RC4_M1_C3
    public bool Isactive;




    #endregion

    #region Constructors

    // Create GraphVoxel constructor--- FROM David RC4_M1_C3
    /// <summary>
    /// Creates a <see cref="GraphVoxel"/>
    /// </summary>
    /// <param name="index">Index on the <see cref="VoxelGrid"/></param>
    /// <param name="voxelGrid">Grid the voxel is to be created at</param>
    /// <param name="state">Initial state the voxel should be set to</param>
    /// <param name="sizeFactor">Factor to scale the GameObject over the voxel size</param>
    public ImageVoxel(Vector3Int index, VoxelGrid voxelGrid, float state, float sizeFactor)
    {
        Index = index;
        _voxelGrid = voxelGrid;
        _size = _voxelGrid.VoxelSize;

        _state = state;

        CreateGameObject();
        
        //_voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/Basic");
        VoxelGO.GetComponent<MeshRenderer>().enabled = false;

        Status = VoxelState.Available;
    }

    #endregion

    #region Public methods

    // Create SetState method for the GraphVoxel
    /// <summary>
    /// Changes the state of the <see cref="GraphVoxel"/>, updating the material
    /// </summary>
    /// <param name="newState">The new state to be set</param>
    public void SetState(float newState)
    {
        //19 Set state field --- FROM David RC4_M1_C3
        _state = newState;

        //<param name="index">Index on the <see cref="VoxelGrid"/></param>
        int x = Index.x;
        int y = Index.y;
        int z = Index.z;
        var s = _voxelGrid.GridSize;
        Isactive = false;


        // Set voxel as void if value is below threshold --- FROM David RC4_M1_C3
        if (y >= 5 && _state <= 0.2)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = false;

            // Create tag in Unity and set here
            VoxelGO.tag = "VoidVoxel";

            //5.20 ADD STATE ALIVE
            Status = VoxelState.Dead;

        }
        // Set BLACK PIXELS as Wall
        else if (_state >= 0.8 && 5 <= y && y <= 24)
        {
            //Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/Wall");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            //Create tag in Unity and set
            VoxelGO.tag = "Wall";

            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;

        }
        // Set y == 0 voxels as floor
        else if (y >= 0 && y <= 4)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/Floor");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            VoxelGO.tag = "Floor";

            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;
        }

        // Set dark gray pixels as roof in 3M
        else if (15 <= y && y <= 19 && _state >= 0.6)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/DARK GRAY");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            VoxelGO.tag = "Roof";


            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;

        }
        // Set mid gray pixels as roof in 2M
        else if (20 <= y && y <= 24 && _state >= 0.2 && _state < 0.6)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/MID GRAY");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            VoxelGO.tag = "Roof";


            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;

        }

        else Status = VoxelState.Dead;


    }

    #region read roof image
    public void SetRoofState(float newState)
    {
        //19 Set state field --- FROM David RC4_M1_C3
        _state = newState;

        //<param name="index">Index on the <see cref="VoxelGrid"/></param>
        int x = Index.x;
        int y = Index.y;
        int z = Index.z;
        var s = _voxelGrid.GridSize;


        // Set voxel as void if value is below threshold --- FROM David RC4_M1_C3
        if (y >= 25 && _state >= 0.9)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");
           VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = false;

            // Create tag in Unity and set here
            VoxelGO.tag = "VoidVoxel";

            //5.20 ADD STATE ALIVE
            Status = VoxelState.Dead;

        }
        // Set BLACK PIXELS as Wall
        else if (y >= 25 && _state <= 0.8 && _state >= 0.6 && y < 30)
        {
            //Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/80");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            //Create tag in Unity and set
            VoxelGO.tag = "Roof";

            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;

        }
        // Set y == 0 voxels as floor
        else if (y >= 25 && _state <= 0.6 && _state >= 0.4 && y < 35)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/60");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            VoxelGO.tag = "Roof";

            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;
        }

        // Set dark gray pixels as roof in 3M
        else if (y >= 25 && _state <= 0.4 && _state >= 0.2 && y < 40)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/40");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            VoxelGO.tag = "Roof";


            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;

        }
        // Set mid gray pixels as roof in 2M
        else if (y >= 25 && _state <= 0.2 && _state > 0.1 && y < 45)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/20");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            VoxelGO.tag = "Roof";


            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;

        }

        else if (y >= 25 && _state <= 0.1 && _state >= 0 && y < 50)
        {
            // Read material and set
            VoxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/0");
            VoxelGO.GetComponent<MeshRenderer>().enabled = true;

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            VoxelGO.tag = "Roof";


            //5.20 ADD STATE ALIVE
            Status = VoxelState.Alive;

        }

        else Status = VoxelState.Dead;


    }
    #endregion



    #endregion
}