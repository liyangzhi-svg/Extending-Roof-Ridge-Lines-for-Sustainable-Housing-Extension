﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;
public enum VoxelState { Dead = 0, Alive = 1, Available = 2, Occupied = 3 }
public class Voxel : IEquatable<Voxel>
{
    #region Public fields

    public Vector3Int Index;
    public List<Face> Faces = new List<Face>(6);
    public Vector3 Center => (Index + _voxelGrid.Origin) * _size;
    public bool IsActive;
    private VoxelState _voxelStatus;
    private bool _showVoxel;
    public GameObject VoxelGO;

    #endregion

    #region Protected fields


    protected VoxelGrid _voxelGrid;
    protected float _size;

    #endregion
    public bool ShowVoxel
    {
        get
        {
            return _showVoxel;
        }
        set
        {
            _showVoxel = value;
            if (!value)
                VoxelGO.SetActive(value);
            else
                VoxelGO.SetActive(Status == VoxelState.Alive);

        }
    }


    public VoxelState Status
    {
        get
        {
            return _voxelStatus;
        }
        set
        {
            //_voxelGO.SetActive(value == VoxelState.Alive && _showVoxel);
            _voxelStatus = value;
        }
    }
    #region Contructors

    /// <summary>
    /// Creates a regular voxel on a voxel grid
    /// </summary>
    /// <param name="index">The index of the Voxel</param>
    /// <param name="voxelgrid">The <see cref="VoxelGrid"/> this <see cref="Voxel"/> is attached to</param>
    /// <param name="voxelGameObject">The <see cref="GameObject"/> used on the Voxel</param>
    public Voxel(Vector3Int index, VoxelGrid voxelGrid, float sizeFactor = 1f)
    {
        Index = index;
        _voxelGrid = voxelGrid;
        _size = _voxelGrid.VoxelSize;


        Status = VoxelState.Available;
    }

    /// <summary>
    /// Generic constructor, alllows the use of inheritance
    /// </summary>
    public Voxel() { }

    #endregion

    #region Public methods

    /// <summary>
    /// Get the neighbouring voxels at each face, if it exists
    /// </summary>
    /// <returns>All neighbour voxels</returns>
    public IEnumerable<Voxel> GetFaceNeighboursList()
    {
        int x = Index.x;
        int y = Index.y;
        int z = Index.z;
        var s = _voxelGrid.GridSize;

        if (x != 0) yield return _voxelGrid.Voxels[x - 1, y, z];
        if (x != s.x - 1) yield return _voxelGrid.Voxels[x + 1, y, z];

        if (y != 0) yield return _voxelGrid.Voxels[x, y - 1, z];
        if (y != s.y - 1) yield return _voxelGrid.Voxels[x, y + 1, z];

        if (z != 0) yield return _voxelGrid.Voxels[x, y, z - 1];
        if (z != s.z - 1) yield return _voxelGrid.Voxels[x, y, z + 1];
    }


    public Voxel[] neighbours = new Voxel[5];

    public Voxel[] GetFaceNeighboursArray()
    {
       
        
        Voxel[] neighbours = new Voxel[Util.Directions.Length];

        for (int i = 0; i < neighbours.Length; i++)
        {
            Vector3Int newIndex = Index + Util.Directions[i];
            if (Util.CheckBounds(newIndex, _voxelGrid))
            {
                neighbours[i] = _voxelGrid.GetVoxelByIndex(newIndex);
            }
        }

        return neighbours;
    }

    /// <summary>
    /// Activates the visibility of this voxel
    /// </summary>
    public void ActivateVoxel(bool state)
    {
        IsActive = state;
        VoxelGO.GetComponent<MeshRenderer>().enabled = state;
        VoxelGO.GetComponent<BoxCollider>().enabled = state;
    }

    public void ChangeGrid(VoxelGrid newGrid)
    {
        _voxelGrid = newGrid;
    }

    public void CreateGameObject()
    {
        VoxelGO = GameObject.CreatePrimitive(PrimitiveType.Cube);
        //Set voxels to the correct position

        VoxelGO.transform.position = _voxelGrid.Origin + Vector3.one * (_voxelGrid.VoxelSize / 2) + (Vector3)Index * _voxelGrid.VoxelSize;
        VoxelGO.transform.localScale *= _voxelGrid.VoxelSize;
        VoxelGO.name = $"{_voxelGrid.Label}_Voxel_{Index.x}_{Index.y}_{Index.z}";
    }

    public void SetGOMaterial(Material material)
    {
        VoxelGO.GetComponent<MeshRenderer>().material = material;
        VoxelGO.GetComponent<MeshRenderer>().enabled = true;
    }

    #endregion

    #region Equality checks

    /// <summary>
    /// Checks if two Voxels are equal based on their Index
    /// </summary>
    /// <param name="other">The <see cref="Voxel"/> to compare with</param>
    /// <returns>True if the Voxels are equal</returns>
    public bool Equals(Voxel other)
    {
        return (other != null) && (Index == other.Index);
    }

    /// <summary>
    /// Get the HashCode of this <see cref="Voxel"/> based on its Index
    /// </summary>
    /// <returns>The HashCode as an Int</returns>
    public override int GetHashCode()
    {
        return Index.GetHashCode();
    }

    #endregion

    //ljw
    public bool IsFloorVoxel()
    {
        int x = Index.x;
        int y = Index.y;
        int z = Index.z;
        var s = _voxelGrid.GridSize;

        bool isFloor = false;

        if (y == 0)
        {
            isFloor = true;
        }
        return isFloor;
    }


    // 6.9 get all the roof voxels
    //public bool IsRoofVoxel()
    //{
    //    bool isRoof = false;

    //    foreach (var neighbours in GetFaceNeighbours())
    //    {


    //        // if any neighbours is null , it is roof voxel

    //        if (neighbours == null)
    //        {
    //            isRoof = true;

    //        }
    //    }

    //    return isRoof;
    //}

    public bool IsRoofVoxel()
    {
        bool isRoof = true;


            int x = Index.x;
            int y = Index.y;
            int z = Index.z;
            var s = _voxelGrid.GridSize;

            // if any neighbours is null , it is roof voxel

            if (_voxelGrid.Voxels[x - 1, y, z] != null  //0
                    && _voxelGrid.Voxels[x + 1, y, z] != null  //1
                    && _voxelGrid.Voxels[x, y, z - 1] != null  //2
                    && _voxelGrid.Voxels[x, y, z + 1] != null  //3
                    && _voxelGrid.Voxels[x, y - 1, z] != null  //4
                    && _voxelGrid.Voxels[x, y + 1, z] != null  //5
                    )
            {
                isRoof = false;

            }
       

        return isRoof;
    }




    public void SetColor(Color color)
    {
        VoxelGO.GetComponent<MeshRenderer>().material.color = color;
    }



    public Vector3 Centre => _voxelGrid.Origin + (Vector3)Index * _voxelGrid.VoxelSize + Vector3.one * 0.5f * _voxelGrid.VoxelSize;

}