using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;





public class CombinatorialFiller : MonoBehaviour
{
    //LJW ����
    private int _triesPerIteration = 10;

    private float _minimumOverlap = 0.6f;

    private int _iterations = 30;

    private int _tryCounter = 0;
    private int _iterationCounter = 0;

    private bool generating = false;
    private int _seed = 0;

    private List<int> test = new List<int>();

    private Dictionary<int, float> _efficiencies = new Dictionary<int, float>();
    private List<int> orderedEfficiencyIndex = new List<int>();

    private VoxelGrid _planGrid;
    private VoxelGrid _planGridBig;
    private VoxelGrid _roofGrid;
    private VoxelGrid _roofGridBig;
    private VoxelGrid _combinedGrid;
    private ImageVoxel _ImageVoxel;
    private CombinatorialFiller _combinatorialFiller;
    private Voxel voxel;
    private float _voxelSize = 1f;
    private Vector3 _origin => transform.position;
    private int _gridStep = 5;


    private List<Voxel> _buildingVoxels;

    private List<PatternPosition> _RoofpatternPositions = new List<PatternPosition>();
    private List<PatternPosition> _PlanpatternPositions = new List<PatternPosition>();

    public List<Voxel> _neighbours = new List<Voxel>();
    Texture2D _sourceImage;
    Texture2D _RoofImage;

    private List<Quaternion> _allDirections;

    public void Start()
    {

        //// Read Image from resources--- FROM David RC4_M1_C3
        _sourceImage = Resources.Load<Texture2D>("Data/plan/P2P9");

        // Create grid from image--- FROM David RC4_M1_C3
        _planGrid = new VoxelGrid(_sourceImage, 24, _origin, 1f, _gridStep, "PlanSmall");
        _planGridBig = new VoxelGrid(((Vector3)_planGrid.GridSize / _gridStep).ToVector3IntCeil(), _origin, _voxelSize * _gridStep, "PlanBig");

        //READ ROOF
        // Read Image from resources--- FROM David RC4_M1_C3
        _RoofImage = Resources.Load<Texture2D>("Data/roof07");


        // Create grid from image--- FROM David RC4_M1_C3
        _roofGrid = new VoxelGrid(_RoofImage, 43, _origin, 1f, _gridStep, "RoofSmall");
        _roofGridBig = new VoxelGrid(((Vector3)_roofGrid.GridSize / _gridStep).ToVector3IntCeil(), _origin, _voxelSize * _gridStep, "RoofBig");


        _allDirections = new List<Quaternion>();
        for (int i = 0; i <= 270; i += 90)
        {
            for (int j = 0; j <= 270; j += 90)
            {
                _allDirections.Add(Quaternion.Euler(i, j, 0));
            }
        }

        
    }
    public void ReadImage()
    {
        //_buildingVoxels = _planGrid.SetStatesFromImage(_sourceImage);
        ////ljw GET AvailableBuildingVoxels
        //_planGrid.FindAvailableBuildingVoxels();
        SetPlanPatternPositions();
        _planGrid.SetStatesFromImage(_sourceImage);
        SetBigPlangridState();

    }

    public void ReadRoofImage()
    {
        SetRoofPatternPositions();
        _roofGrid.SetRoofStatesFromImage(_RoofImage);
        SetBigRoofgridState();

    }





    public void Update()
    {

        if (Input.GetKeyDown("space"))
        {
            //TryAddRandomBlock();

            if (!generating)
            {
                generating = true;

                // Make this a for loop
                // Every time you start, clean your voxels and delete placed blocks
                // After each iteration of the loop, add +1 to _seed

                //BRUTEforce fill
                //StartCoroutine(AddBlocks());


                //slow
                //StartCoroutine(BruteforceBlocks());


                //one by one
                //StartCoroutine(TryAddBlocks());
                //Addparts();


                //roof
                StartCoroutine(PlaceRoofComponent());
                //PlaceRoofComponent();

            }
            else
            {
                generating = false;
                StopAllCoroutines();
            }
        }


        if (Input.GetKeyDown(KeyCode.I))
        {
            //TryAddRandomBlock();

            if (!generating)
            {
                generating = true;

                //roof
                PlacePlanComponent();

            }
            else
            {
                generating = false;
                StopAllCoroutines();
            }
        }


        if (Input.GetKeyDown(KeyCode.A))
        {
            _combinedGrid = _planGrid.CombineGrids(_roofGrid);
        }

        if (Input.GetKeyDown(KeyCode.P))
        {
            //one by one
            StartCoroutine(TryAddBlocks());
            //Addparts();
        }

        if (Input.GetKeyDown(KeyCode.O))
        {
            //BRUTEforce fill
            StartCoroutine(AddBlocks());
        }
    }


    #region Plan Operations
    private bool PlaceBestFittingBlock(Vector3Int anchor)
    {
        Dictionary<Quaternion, int> possibleDirections = new Dictionary<Quaternion, int>();
        foreach (Quaternion direction in _allDirections)
        {
            var checkBlock = _planGrid.CreateCheckBlock(anchor, direction);

            //if (checkBlock.State == BlockState.Valid) possibleDirections.Add(direction, checkBlock.VoxelStatusAmount(VoxelState.Alive));

            //Check blockstate
            if (checkBlock.State == BlockState.Valid && !checkBlock.Voxels.Any(v => v.Status == VoxelState.Occupied))
            {
                possibleDirections.Add(direction, checkBlock.VoxelStatusAmount(VoxelState.Alive));
                //Debug.Log("possibleDirections");
            }
        }

        if (possibleDirections.Count == 0) return false;


        int maxOverlap = possibleDirections.Values.Max();
        var bestDirections = possibleDirections.Where(v => v.Value == maxOverlap).Select(p => p.Key).ToList();

        int index = Random.Range(0, bestDirections.Count);


        _planGrid.SetFloorType();
        _planGrid.AddBlock(anchor, bestDirections[index]);
        bool blockAdded = _planGrid.TryAddCurrentBlocksToGrid();
        //ljw check
        //Debug.Log("block");
        _planGrid.PurgeUnplacedBlocks();

        return blockAdded;
    }


    private bool TryPlaceBestBlock(Vector3Int anchor)
    {
        Dictionary<Quaternion, int> possibleDirections = new Dictionary<Quaternion, int>();

        // Set block type
        _planGrid.SetFloorType();

        foreach (Quaternion direction in _allDirections)
        {
            var checkBlock = _planGrid.CreateCheckBlock(anchor, direction);

            //Calculate the minimum overlap based on current type
            int amountOfVoxels = _planGrid.GetCurrentPattern().Indices.Count;
            float blockOverlap = checkBlock.VoxelStatusAmount(VoxelState.Alive) / amountOfVoxels;

            //if (checkBlock.State == BlockState.Valid) possibleDirections.Add(direction, checkBlock.VoxelStatusAmount(VoxelState.Alive));

            //Check blockstate
            if (checkBlock.State == BlockState.Valid
                && !checkBlock.Voxels.Any(v => v.Status == VoxelState.Occupied)
                && blockOverlap >= _minimumOverlap)
            {
                possibleDirections.Add(direction, checkBlock.VoxelStatusAmount(VoxelState.Alive));
                //Debug.Log("possibleDirections");
            }
        }

        if (possibleDirections.Count == 0) return false;

        int maxOverlap = possibleDirections.Values.Max();
        var bestDirections = possibleDirections.Where(v => v.Value == maxOverlap).Select(p => p.Key).ToList();

        // Get any of the orientations with the maximum overlap
        int index = Random.Range(0, bestDirections.Count);

        _planGrid.AddBlock(anchor, bestDirections[index]);
        bool blockAdded = _planGrid.TryAddCurrentBlocksToGrid();
        //ljw check
        //Debug.Log("block");
        _planGrid.PurgeUnplacedBlocks();

        return blockAdded;
    }

    private IEnumerator TryAddBlocks()
    {
        //var voxels = _voxelGrid.GetFlattenedVoxels().Where(v => v.Status == VoxelState.Alive).ToList();
        List<Voxel> skipped = new List<Voxel>();
        while (_planGrid.GetFlattenedVoxels().Count(v => v.Status == VoxelState.Alive && !skipped.Contains(v)) > 0)
        {
            int ind = Random.Range(0, _planGrid.GetFlattenedVoxels().Capacity);
            // get voxel at index ind, instead of first
            var voxel = _planGrid.GetFlattenedVoxels().First(v => v.Status == VoxelState.Alive && !skipped.Contains(v));

            // Define the pattern based on the index of the voxel
            // LJW check which voxel contains
            //Debug.Log("add");
            //_voxelGrid.Voxels[voxel.Index.x, voxel.Index.y, voxel.Index.z]._voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");
            _planGrid.Voxels[voxel.Index.x, voxel.Index.y, voxel.Index.z].VoxelGO.GetComponent<MeshRenderer>().enabled = false;


            if (!TryPlaceBestBlock(voxel.Index))
            {
                skipped.Add(voxel);
            }

            yield return new WaitForSeconds(0.01f);
        }
        // store the random seed value and the amount of empty voxels in a dictionary
    }

    private IEnumerator AddBlocks()
    {
        List<Voxel> skipped = new List<Voxel>();
        List<Voxel> availableVoxels = _buildingVoxels.Where(v => v.Status == VoxelState.Alive && !skipped.Contains(v)).ToList();
        while (availableVoxels.Count > 0)
        {
            int ind = Random.Range(0, availableVoxels.Count);
            var voxel = availableVoxels[ind];

            // Define the pattern based on the index of the voxel
            // LJW check which voxel contains
            //Debug.Log("add");
            //_voxelGrid.Voxels[voxel.Index.x, voxel.Index.y, voxel.Index.z]._voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");
            _planGrid.Voxels[voxel.Index.x, voxel.Index.y, voxel.Index.z].VoxelGO.GetComponent<MeshRenderer>().enabled = false;

            //if (!PlaceBestFittingBlock(voxel.Index))
            //{
            //    skipped.Add(voxel);
            //}
            if (!TryPlaceBestBlock(voxel.Index))
            {
                skipped.Add(voxel);
            }

            yield return new WaitForEndOfFrame();
        }

        //Keep track of the most efficient seeds
        _efficiencies.Add(_seed, _planGrid.Efficiency);
        orderedEfficiencyIndex = _efficiencies.Keys.OrderByDescending(k => _efficiencies[k]).Take(11).ToList();
        if (orderedEfficiencyIndex.Count == 11)
            _efficiencies.Remove(orderedEfficiencyIndex[10]);

        // Update the available Voxels
        availableVoxels = _buildingVoxels.Where(v => v.Status == VoxelState.Alive && !skipped.Contains(v)).ToList();
    }

    private void Addparts()
    {
        _planGrid.PurgeAllBlocks();
        _tryCounter = 0;

        while (_tryCounter < _triesPerIteration)
        {
            StartCoroutine(TryAddBlocks());
            _tryCounter++;
        }

        //Keep track of the most efficient seeds
        _efficiencies.Add(_seed, _planGrid.Efficiency);
        orderedEfficiencyIndex = _efficiencies.Keys.OrderByDescending(k => _efficiencies[k]).Take(11).ToList();
        if (orderedEfficiencyIndex.Count == 11)
            _efficiencies.Remove(orderedEfficiencyIndex[10]);
    }


    private IEnumerator BruteforceBlocks()
    {
        while (_iterationCounter < _iterations)
        {
            Random.InitState(_seed);

            AddBlocks();
            Debug.Log($"Seed {_seed} efficiency: {_efficiencies[_seed]}");

            _iterationCounter++;
            _seed = _seed++;

            yield return new WaitForSeconds(0.01f);
        }
    }

    #endregion

    #region Roof Operations


    private Pattern _currentPattern;


    //+x rotation

   public Quaternion XMinRotation()
    {
        int x = 0;
        int y = -90;
        int z = 0;
        return Quaternion.Euler(x, y, z);
    }
    public Quaternion XPlusRotation()
    {
        int x = 0;
        int y = 90;
        int z = 0;
        return Quaternion.Euler(x, y, z);
    }

    //+y rotation

    public Quaternion YMinRotation()
    {
        int x = 90;
        int y = 0;
        int z = 0;
        return Quaternion.Euler(x, y, z);
    }

    public Quaternion YPlusRotation()
    {
        int x = -90;
        int y = 0;
        int z = 0;
        return Quaternion.Euler(x, y, z);
    }



    public Quaternion ZMinRotation()
    {
        int x = 0;
        int y = 180;
        int z = 0;
        return Quaternion.Euler(x, y, z);
    }

    public Quaternion ZPlusRotation()
    {
        int x = 0;
        int y = 0;
        int z = 0;
        return Quaternion.Euler(x, y, z);
    }

    private void SetRoofPatternPositions()//Run this in the start of 
    {
        //Add all the patterns

        //  pattern C 
        _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(-1,0,0),//0
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { XMinRotation() }));


                _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(1,0,0),//1
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { XPlusRotation() }));


                        _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(0,0,-1),//2
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { ZMinRotation() }));

                                _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(0,0,+1),//3
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { ZPlusRotation() }));


           _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
               new Vector3Int(-1,0,0),//0
               new Vector3Int(+1,0,0),//1
            new Vector3Int(0,0,+1),//3
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { ZPlusRotation() }));

                   _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
               new Vector3Int(-1,0,0),//0
               new Vector3Int(+1,0,0),//1
            new Vector3Int(0,0,-1),//2
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { ZMinRotation() }));

                           _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
               new Vector3Int(-1,0,0),//0
            new Vector3Int(0,0,-1),//2
            new Vector3Int(0,0,+1),//3
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { XMinRotation() }));


                                   _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
               new Vector3Int(+1,0,0),//1
            new Vector3Int(0,0,-1),//2
            new Vector3Int(0,0,+1),//3
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[2] },
           new List<Quaternion>() { XPlusRotation() }));



        //pattern D

        _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(-1,0,0)//0          
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
           new List<Quaternion>() { XMinRotation() }));

                _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(+1,0,0)//1          
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
           new List<Quaternion>() { XPlusRotation() }));

                        _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(0,0,-1)//2          
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
           new List<Quaternion>() { ZMinRotation() }));


           _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(0,0,1)//3          
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
           new List<Quaternion>() { ZPlusRotation() }));


                _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(-1,0,0),//0
            new Vector3Int(0,0,-1)//2                       
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
           new List<Quaternion>() { XMinRotation(), ZMinRotation() }));

        _RoofpatternPositions.Add(new PatternPosition(
          new List<Vector3Int>()
          {
            new Vector3Int(-1,0,0),//0
            new Vector3Int(0,0,1)//3                     
          },

          new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
          new List<Quaternion>() { XMinRotation(), ZPlusRotation() }));


                        _RoofpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(+1,0,0),//1  
            new Vector3Int(0,0,-1)//2                       
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
           new List<Quaternion>() { XPlusRotation(), ZMinRotation() }));

        _RoofpatternPositions.Add(new PatternPosition(
          new List<Vector3Int>()
          {
            new Vector3Int(+1,0,0),//1 
            new Vector3Int(0,0,1)//3                     
          },

          new List<Pattern>() { PatternManager.Patterns.ToList()[3] },
          new List<Quaternion>() { XPlusRotation(), ZPlusRotation() }));







        //pattern E
        _RoofpatternPositions.Add(new PatternPosition(
            new List<Vector3Int>()
            {
            new Vector3Int(-1,0,0),//0
            new Vector3Int(0,0,-1),//2
            new Vector3Int(0,+1,0)//5
            },

            new List<Pattern>() { PatternManager.Patterns.ToList()[4] },
            new List<Quaternion>() { XMinRotation() }));

                    _RoofpatternPositions.Add(new PatternPosition(
            new List<Vector3Int>()
            {
            new Vector3Int(+1,0,0),//1
            new Vector3Int(0,0,-1),//2
            new Vector3Int(0,+1,0)//5
            },

            new List<Pattern>() { PatternManager.Patterns.ToList()[4] },
            new List<Quaternion>() { ZMinRotation() }));

                            _RoofpatternPositions.Add(new PatternPosition(
            new List<Vector3Int>()
            {
            new Vector3Int(+1,0,0),//1
            new Vector3Int(0,0,+1),//3
            new Vector3Int(0,+1,0)//5
            },

            new List<Pattern>() { PatternManager.Patterns.ToList()[4] },
            new List<Quaternion>() { XPlusRotation() }));

             _RoofpatternPositions.Add(new PatternPosition(
            new List<Vector3Int>()
            {
            new Vector3Int(-1,0,0),//0
            new Vector3Int(0,0,+1),//3
            new Vector3Int(0,+1,0)//5
            },

            new List<Pattern>() { PatternManager.Patterns.ToList()[4] },
            new List<Quaternion>() { ZPlusRotation() }));






        //pattern A

        _RoofpatternPositions.Add(new PatternPosition(
    new List<Vector3Int>()
    {
            new Vector3Int(0,+1,0)//5
    },
    new List<Pattern>() { PatternManager.Patterns.ToList()[0] },
    new List<Quaternion>() { YPlusRotation() }));





        //RotatePatternsAndPatternPositions();
    }

    private void SetPlanPatternPositions()//Run this in the start of 
    {
        //Add all the patterns

        //  FLOOR
        _PlanpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(0,+1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
           new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
           new List<Vector3Int>()
           {
            new Vector3Int(0,-1,0)//5
           },

           new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
           new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

                _PlanpatternPositions.Add(new PatternPosition(
         new List<Vector3Int>()
         {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(0,+1,0)//5
         },

         new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
         new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));
        _PlanpatternPositions.Add(new PatternPosition(
         new List<Vector3Int>()
         {
            new Vector3Int(-1,0,0),//5
            new Vector3Int(0,+1,0),//5
         },

         new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
         new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(0,0,+1),//5
            new Vector3Int(0,+1,0),//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

          _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(0,0,-1),//5
            new Vector3Int(0,+1,0),//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));


        _PlanpatternPositions.Add(new PatternPosition(
          new List<Vector3Int>()
          {
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
          },

          new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
          new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));
        _PlanpatternPositions.Add(new PatternPosition(
         new List<Vector3Int>()
         {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
         },

         new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
         new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));
        _PlanpatternPositions.Add(new PatternPosition(
         new List<Vector3Int>()
         {
            new Vector3Int(-1,0,0),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
         },

         new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
         new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(0,0,+1),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

          _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(0,0,-1),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

          _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(0,0,+1),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(0,0,-1),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(-1,0,0),//5
            new Vector3Int(0,0,+1),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
        new List<Vector3Int>()
        {
            new Vector3Int(-1,0,0),//5
            new Vector3Int(0,0,-1),//5
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,-1,0)//5
        },

        new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
        new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation() }));


        //10001
        _PlanpatternPositions.Add(new PatternPosition(
       new List<Vector3Int>()
       {
            new Vector3Int(-1,0,0),//5
            new Vector3Int(0,0,-1),//5
            new Vector3Int(0,0,+1),//5
       },

       new List<Pattern>() { PatternManager.Patterns.ToList()[6]},
       new List<Quaternion>() { XMinRotation()}));

       _PlanpatternPositions.Add(new PatternPosition(
       new List<Vector3Int>()
       {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(0,0,-1),//5
            new Vector3Int(0,0,+1),//5
       },

       new List<Pattern>() { PatternManager.Patterns.ToList()[6]},
       new List<Quaternion>() { XPlusRotation()}));

        _PlanpatternPositions.Add(new PatternPosition(
       new List<Vector3Int>()
       {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(-1,0,0),//5
            new Vector3Int(0,0,+1),//5
       },

       new List<Pattern>() { PatternManager.Patterns.ToList()[6] },
       new List<Quaternion>() { ZPlusRotation() }));

       _PlanpatternPositions.Add(new PatternPosition(
       new List<Vector3Int>()
       {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(-1,0,0),//5
            new Vector3Int(0,0,-1),//5
       },

       new List<Pattern>() { PatternManager.Patterns.ToList()[6] },
       new List<Quaternion>() { ZMinRotation() }));

        //01110

        _PlanpatternPositions.Add(new PatternPosition(
       new List<Vector3Int>()
       {
            new Vector3Int(+1,0,0),//5
            new Vector3Int(-1,0,0),//5
       },

       new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
       new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation(), YMinRotation(), YPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
     new List<Vector3Int>()
     {
            new Vector3Int(0,0,+1),//5
            new Vector3Int(0,0,-1),//5
     },

     new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
     new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation(), YMinRotation(), YPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
      new List<Vector3Int>()
      {
            new Vector3Int(0,+1,0),//5
            new Vector3Int(+1,0,0),//5
            new Vector3Int(-1,0,0),//5
      },

      new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
      new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation(), YMinRotation(), YPlusRotation() }));

        _PlanpatternPositions.Add(new PatternPosition(
     new List<Vector3Int>()
     {
            new Vector3Int(0,+1,0),//5
            new Vector3Int(0,0,+1),//5
            new Vector3Int(0,0,-1),//5
     },

     new List<Pattern>() { PatternManager.Patterns.ToList()[7], PatternManager.Patterns.ToList()[8], PatternManager.Patterns.ToList()[9], PatternManager.Patterns.ToList()[10] },
     new List<Quaternion>() { XMinRotation(), ZMinRotation(), XPlusRotation(), ZPlusRotation(), YMinRotation(), YPlusRotation() }));


    }



    //public void RotatePatternsAndPatternPositions()
    //{
    //    List<PatternPosition> newPatternPositions = new List<PatternPosition>();
    //    foreach (var patternPos in _patternPositions)
    //    {
    //        for (int y = 0; y < 4; y++)
    //        {
    //            List<Pattern> linkedPatterns = new List<Pattern>();

    //            foreach (var pattern in patternPos.PossiblePatterns)
    //            {
    //                Pattern newPattern = pattern.GetRotatedPattern(Quaternion.Euler(0, y * 90, 0));
    //                Pattern existingPattern = PatternManager.Patterns.First(p => p.Equals(newPattern));
    //                if (existingPattern != null) linkedPatterns.Add(existingPattern);
    //                else
    //                {
    //                    PatternManager.Instance.AddPattern(newPattern);
    //                    linkedPatterns.Add(newPattern);
    //                }

    //            }

    //            newPatternPositions.Add(patternPos.GetRotatedPatternPosition(Quaternion.Euler(0, y * 90, 0), linkedPatterns));
    //        }
    //    }
    //    _patternPositions.AddRange(newPatternPositions);
    //}



    public List<Pattern> GetPossiblePatterns(Voxel voxel)
    {
        Voxel[] neighbours = voxel.GetFaceNeighboursArray();

        List<PatternPosition> possiblePatternPositions = new List<PatternPosition>();

        foreach (var patternPos in _RoofpatternPositions)
        {
            bool checkPattern = true;
            for (int i = 0; i < 6; i++)
            {
                if (

                    (neighbours[i] == null) == (patternPos.Positions.Contains(Util.Directions[i])) ||
                    (neighbours[i].Status == VoxelState.Dead) == (patternPos.Positions.Contains(Util.Directions[i]))
                    )

                //neighbours[i] == null || neighbours[i].Status == VoxelState.Dead)

                {
                    checkPattern = false;
                }
            }
            if (checkPattern) possiblePatternPositions.Add(patternPos);
        }

        List<Pattern> possiblePatterns = possiblePatternPositions.SelectMany(p => p.PossiblePatterns).ToList();

        return possiblePatterns;
    }

    public List<Vector3Int> GetVoxelDeadNeighbours(Voxel voxel)
    {
        Voxel[] neighbours = voxel.GetFaceNeighboursArray();

        List<Vector3Int> VoxelDeadNeighbours = new List<Vector3Int>();


                for (int i = 0; i < 6; i++)
                {
                    if (
                        (neighbours[i] == null || neighbours[i].Status == VoxelState.Dead) && i != 4
                        )

                    {
                        VoxelDeadNeighbours.Add(Util.Directions[i]);
                    }
                }

        return VoxelDeadNeighbours;
    }
    public List<Vector3Int> GetVoxelDeadNeighbours2(Voxel voxel)
    {
        Voxel[] neighbours = voxel.GetFaceNeighboursArray();

        List<Vector3Int> VoxelDeadNeighbours = new List<Vector3Int>();


        for (int i = 0; i < 6; i++)
        {
            if (
                neighbours[i] == null || neighbours[i].Status == VoxelState.Dead
                )

            {
                VoxelDeadNeighbours.Add(Util.Directions[i]);
            }
        }

        return VoxelDeadNeighbours;
    }



    public List<Vector3Int> GetVoxels(Voxel voxel)
    {

        List<Vector3Int> GetVoxels = new List<Vector3Int>();
        return GetVoxels;
    }

    public IEnumerator PlaceRoofComponent()
    {

        foreach (var voxel in _roofGridBig.GetBoundaryVoxels())
        {

            int x = voxel.Index.x;
            int y = voxel.Index.y;
            int z = voxel.Index.z;
            var s = _roofGridBig.GridSize;

            //small grid center
            int sx = voxel.Index.x * 5 + 2;
            int sy = voxel.Index.y * 5 + 2;
            int sz = voxel.Index.z * 5 + 2;
            var ss = _roofGrid.GridSize;
            var neighbours = voxel.GetFaceNeighboursArray();

            //List<Pattern> possiblePatterns = GetPossiblePatterns(voxel);
            List<Vector3Int> VoxelDeadNeighbours = GetVoxelDeadNeighbours(voxel);

            foreach (var patternPos in _RoofpatternPositions)
            {

                    if (
                    VoxelDeadNeighbours.All(patternPos.Positions.Contains) && VoxelDeadNeighbours.Count == patternPos.Positions.Count

                        )

                    {
                        //change block
                        voxel.VoxelGO.GetComponent<MeshRenderer>().enabled = false;

                        foreach (var smallvoxel in GetSmallVoxels(voxel,_roofGrid))
                        {
                            smallvoxel.VoxelGO.GetComponent<MeshRenderer>().enabled = false;
                        }



                        int p = Random.Range(0, patternPos.PossiblePatterns.Count);
                        int r = Random.Range(0, patternPos.Rotation.Count);

                    //add block
                        _roofGrid._currentPattern = patternPos.PossiblePatterns[p];
                        _roofGrid.AddBlock(new Vector3Int(sx, sy, sz), patternPos.Rotation[r]);
                        _roofGrid.TryAddCurrentBlocksToGrid();
                        //ljw check
                        Debug.Log("2X0");
                        _roofGrid.PurgeUnplacedBlocks();
                    yield return new WaitForSeconds(0.1f);
                }

            }


        }
    }


    public void PlacePlanComponent()
    {

        foreach (var voxel in _planGridBig.GetAliveVoxels())
        {

            int x = voxel.Index.x;
            int y = voxel.Index.y;
            int z = voxel.Index.z;
            var s = _planGridBig.GridSize;

            //small grid center
            int sx = voxel.Index.x * 5 + 2;
            int sy = voxel.Index.y * 5 + 2;
            int sz = voxel.Index.z * 5 + 2;
            var ss = _planGrid.GridSize;
            var neighbours = voxel.GetFaceNeighboursArray();

            //List<Pattern> possiblePatterns = GetPossiblePatterns(voxel);
            List<Vector3Int> WallVoxels = GetVoxelDeadNeighbours2(voxel);

            foreach (var patternPos in _PlanpatternPositions)
            {

                if (
                WallVoxels.All(patternPos.Positions.Contains) && WallVoxels.Count == patternPos.Positions.Count

                    )

                {
                    //change block
                    voxel.VoxelGO.GetComponent<MeshRenderer>().enabled = false;

                    foreach (var smallvoxel in GetSmallVoxels(voxel, _planGrid))
                    {
                        smallvoxel.VoxelGO.GetComponent<MeshRenderer>().enabled = false;
                    }



                    int p = Random.Range(0, patternPos.PossiblePatterns.Count);
                    int r = Random.Range(0, patternPos.Rotation.Count);

                    //add block
                    _planGrid._currentPattern = patternPos.PossiblePatterns[p];
                    _planGrid.AddBlock(new Vector3Int(sx, sy, sz), patternPos.Rotation[r]);
                    _planGrid.TryAddCurrentBlocksToGrid();
                    //ljw check
                    Debug.Log("2X0");
                    _planGrid.PurgeUnplacedBlocks();

                    //yield return new WaitForSeconds(0.001f);
                }

            }


        }
    }




    #endregion

    Vector3Int GetBigVoxelIndex(Vector3Int smallVoxelIndex)
    {
        return ((Vector3)smallVoxelIndex * 0.2f).ToVector3IntFloor();
    }

    IEnumerable<Vector3Int> GetSmallVoxelIndices(Vector3Int bigVoxelIndex)
    {
        for (int x = bigVoxelIndex.x * 5; x < bigVoxelIndex.x * 5 + 5; x++)
            for (int y = bigVoxelIndex.y * 5; y < bigVoxelIndex.y * 5 + 5; y++)
                for (int z = bigVoxelIndex.z * 5; z < bigVoxelIndex.z * 5 + 5; z++)
                    yield return new Vector3Int(x, y, z);
    }



    public IEnumerable<Voxel> GetSmallVoxels(Voxel bigVoxel, VoxelGrid grid)
    {
        for (int x = bigVoxel.Index.x * 5; x < bigVoxel.Index.x * 5 + 5; x++)
            for (int y = bigVoxel.Index.y * 5; y < bigVoxel.Index.y * 5 + 5; y++)
                for (int z = bigVoxel.Index.z * 5; z < bigVoxel.Index.z * 5 + 5; z++)
                    yield return grid.Voxels[x, y, z];
    }




    // according to small voxel status to get bigvoxel status
    public void SetBigRoofgridState()
    {
        foreach (var voxel in _roofGridBig.Voxels)
        {

            voxel.CreateGameObject();
            voxel.VoxelGO.GetComponent<MeshRenderer>().enabled = false;

            voxel.Status = VoxelState.Dead;


            if (GetSmallVoxels(voxel, _roofGrid).Any(v => v.Status != VoxelState.Dead))
            {
                voxel.Status = VoxelState.Available;

                //voxel.VoxelGO.GetComponent<MeshRenderer>().enabled = true;
                //voxel.SetGOMaterial(Resources.Load<Material>("Materials/Bigvoxel"));
            }
            else voxel.Status = VoxelState.Dead;
        }
    }

    public void SetBigPlangridState()
    {
        //_planGrid.ReduceGOVoxels();

        foreach (var voxel in _planGridBig.Voxels)
        {
            voxel.CreateGameObject();
            voxel.VoxelGO.GetComponent<MeshRenderer>().enabled = false;

            voxel.Status = VoxelState.Dead;


            if (GetSmallVoxels(voxel, _planGrid).Count(v => v.Status != VoxelState.Dead) > 60)
            {
                voxel.Status = VoxelState.Alive;

                voxel.VoxelGO.GetComponent<MeshRenderer>().enabled = true;
                voxel.SetGOMaterial(Resources.Load<Material>("Materials/Bigvoxel"));
            }
            else voxel.Status = VoxelState.Dead;
        }
    }



}