using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using UnityEngine;

/// <summary>
/// PatternType can be refered to by name. These can become your block names to make your code more readible. This enum can also be casted to it's assigned integer values. Only define used block types.
/// </summary>
//public enum PatternType { PatternA = 0, PatternB = 1, PatternC = 2, PatternD = 3, PatternE = 4 ,Pattern Floor = 5,
//Pattern 2-1 = 6,Pattern 2-2 = 7,,Pattern 3-1 = 8,Pattern 3-2 = 9,Pattern 3-3 = 10
//
//}

/// <summary>
/// The pattern manager is a singleton class. This means there is only one instance of the PatternManager class in the entire project and it can be refered to anywhere withing the project
/// </summary>
public class PatternManager
{
    /// <summary>
    /// Singleton object of the PatternManager class. Refer to this to access the date inside the object.
    /// </summary>
    public static PatternManager Instance { get; } = new PatternManager();

    private static List<Pattern> _patterns;
    /// <summary>
    /// returns a read only list of the patterns defined in the project
    /// </summary>
    public static List<Pattern> Patterns => new ReadOnlyCollection<Pattern>(_patterns).ToList();

    /// <summary>
    /// private constructor. All initial patterns will be defined in here
    /// </summary>
    private PatternManager()
    {
        _patterns = new List<Pattern>();

        //Define pattern A
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                    new Vector3Int(1, 0, 0),
                    new Vector3Int(2, 0, 0),
                    new Vector3Int(3, 0, 0),
                    new Vector3Int(4, 0, 0),
                    new Vector3Int(0, 1, 0),
                    new Vector3Int(1, 1, 0),
                    new Vector3Int(2, 1, 0),
                    new Vector3Int(3, 1, 0),
                    new Vector3Int(4, 1, 0),
                    new Vector3Int(0, 2, 0),
                    new Vector3Int(1, 2, 0),
                    new Vector3Int(2, 2, 0),
                    new Vector3Int(3, 2, 0),
                    new Vector3Int(4, 2, 0),
                    new Vector3Int(0, 3, 0),
                    new Vector3Int(1, 3, 0),
                    new Vector3Int(2, 3, 0),
                    new Vector3Int(3, 3, 0),
                    new Vector3Int(4, 3, 0),
                    new Vector3Int(0, 4, 0),
                    new Vector3Int(1, 4, 0),
                    new Vector3Int(2, 4, 0),
                    new Vector3Int(3, 4, 0),
                    new Vector3Int(4, 4, 0),
                }
                );

        //Define pattern B
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                    new Vector3Int(1, 0, 0),
                    new Vector3Int(2, 0, 0),
                    new Vector3Int(3, 0, 0),
                    new Vector3Int(0, 1, 0),
                    new Vector3Int(1, 1, 0),
                    new Vector3Int(2, 1, 0),
                    new Vector3Int(3, 1, 0),
                    new Vector3Int(0, 2, 0),
                    new Vector3Int(1, 2, 0),
                    new Vector3Int(2, 2, 0),
                    new Vector3Int(3, 2, 0),
                    new Vector3Int(0, 3, 0),
                    new Vector3Int(1, 3, 0),
                    new Vector3Int(2, 3, 0),
                    new Vector3Int(3, 3, 0),
                    new Vector3Int(0, 4, 0),
                    new Vector3Int(1, 4, 0),
                    new Vector3Int(2, 4, 0),
                    new Vector3Int(3, 4, 0),
                }
                );


        //Define pattern C
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                    new Vector3Int(1, 0, 0),
                    new Vector3Int(2, 0, 0),
                    new Vector3Int(3, 0, 0),
                    new Vector3Int(4, 0, 0),
                    new Vector3Int(0, 1, 0),
                    new Vector3Int(1, 1, 0),
                    new Vector3Int(2, 1, 0),
                    new Vector3Int(3, 1, 0),
                    new Vector3Int(4, 1, 0),
                    new Vector3Int(0, 2, 0),
                    new Vector3Int(1, 2, 0),
                    new Vector3Int(2, 2, 0),
                    new Vector3Int(3, 2, 0),
                    new Vector3Int(4, 2, 0),
                    new Vector3Int(0, 3, 0),
                    new Vector3Int(1, 3, 0),
                    new Vector3Int(2, 3, 0),
                    new Vector3Int(3, 3, 0),
                    new Vector3Int(4, 3, 0),
                    new Vector3Int(0, 4, 0),
                    new Vector3Int(1, 4, 0),
                    new Vector3Int(2, 4, 0),
                    new Vector3Int(3, 4, 0),
                    new Vector3Int(4, 4, 0),

                    new Vector3Int(0, 5, 0),
                    new Vector3Int(1, 5, 0),
                    new Vector3Int(2, 5, 0),
                    new Vector3Int(3, 5, 0),
                    new Vector3Int(4, 5, 0),
                }
                );

        //Define pattern D
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                    new Vector3Int(1, 0, 0),
                    new Vector3Int(2, 0, 0),
                    new Vector3Int(3, 0, 0),
                    new Vector3Int(4, 0, 0),
                    new Vector3Int(0, 1, 1),
                    new Vector3Int(1, 1, 1),
                    new Vector3Int(2, 1, 1),
                    new Vector3Int(3, 1, 1),
                    new Vector3Int(4, 1, 1),
                    new Vector3Int(0, 2, 2),
                    new Vector3Int(1, 2, 2),
                    new Vector3Int(2, 2, 2),
                    new Vector3Int(3, 2, 2),
                    new Vector3Int(4, 2, 2),
                    new Vector3Int(0, 3, 3),
                    new Vector3Int(1, 3, 3),
                    new Vector3Int(2, 3, 3),
                    new Vector3Int(3, 3, 3),
                    new Vector3Int(4, 3, 3),
                    new Vector3Int(0, 4, 4),
                    new Vector3Int(1, 4, 4),
                    new Vector3Int(2, 4, 4),
                    new Vector3Int(3, 4, 4),
                    new Vector3Int(4, 4, 4),

                    new Vector3Int(0, 5, 5),
                    new Vector3Int(1, 5, 5),
                    new Vector3Int(2, 5, 5),
                    new Vector3Int(3, 5, 5),
                    new Vector3Int(4, 5, 5),
                }
                );


        //Define pattern E
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                    new Vector3Int(1, 0, 0),
                    new Vector3Int(2, 0, 0),
                    new Vector3Int(3, 0, 0),
                    new Vector3Int(4, 0, 0),
                    new Vector3Int(0, 1, 1),
                    new Vector3Int(1, 1, 1),
                    new Vector3Int(2, 1, 1),
                    new Vector3Int(3, 1, 1),
                    new Vector3Int(4, 1, 1),

                    new Vector3Int(1, 2, 2),
                    new Vector3Int(2, 2, 2),
                    new Vector3Int(3, 2, 2),
                    new Vector3Int(4, 2, 2),

                    new Vector3Int(2, 3, 3),
                    new Vector3Int(3, 3, 3),
                    new Vector3Int(4, 3, 3),

                    new Vector3Int(3, 4, 4),
                    new Vector3Int(4, 4, 4),

                    new Vector3Int(5, 5, 5),

                    new Vector3Int(0, 1, 0),
                    new Vector3Int(0, 2, 0),
                    new Vector3Int(0, 3, 0),
                    new Vector3Int(0, 4, 0),

                    new Vector3Int(1, 1, 1),
                    new Vector3Int(1, 2, 1),
                    new Vector3Int(1, 3, 1),
                    new Vector3Int(1, 4, 1),

                    new Vector3Int(2, 2, 2),
                    new Vector3Int(2, 3, 2),
                    new Vector3Int(2, 4, 2),

                    new Vector3Int(3, 3, 3),
                    new Vector3Int(3, 4, 3),

                    new Vector3Int(4, 4, 4),

                }
                );

        //Define pattern Floor
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                    new Vector3Int(1, 0, 0),
                    new Vector3Int(2, 0, 0),
                    new Vector3Int(3, 0, 0),
                    new Vector3Int(4, 0, 0),
                    new Vector3Int(0, 1, 0),
                    new Vector3Int(1, 1, 0),
                    new Vector3Int(2, 1, 0),
                    new Vector3Int(3, 1, 0),
                    new Vector3Int(4, 1, 0),
                    new Vector3Int(0, 2, 0),
                    new Vector3Int(1, 2, 0),
                    new Vector3Int(2, 2, 0),
                    new Vector3Int(3, 2, 0),
                    new Vector3Int(4, 2, 0),
                    new Vector3Int(0, 3, 0),
                    new Vector3Int(1, 3, 0),
                    new Vector3Int(2, 3, 0),
                    new Vector3Int(3, 3, 0),
                    new Vector3Int(4, 3, 0),
                    new Vector3Int(0, 4, 0),
                    new Vector3Int(1, 4, 0),
                    new Vector3Int(2, 4, 0),
                    new Vector3Int(3, 4, 0),
                    new Vector3Int(4, 4, 0),
                }
                );
        //Define pattern 2-1
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),

                }
                );
        //Define pattern 2-2
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),

                }
                );
        //Define pattern 3-1
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
  
                }
                );
        //Define pattern 3-2
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                   
                }
                );
        //Define pattern 3-3
        AddPattern(
            new List<Vector3Int>()
                {
                    new Vector3Int(0, 0, 0),
                    
                }
                );

    }
    /// <summary>
    /// Use this method rather than adding directly to the _patterns field. This method will check if the pattern is valid and can be added to the list. Invalid input will be refused.
    /// </summary>
    /// <param name="indices">List of indices that define the patter. The indices should always relate to Vector3In(0,0,0) as anchor point</param>
    /// <param name="type">The PatternType of this pattern to add. Each type can only exist once</param>
    /// <returns></returns>
    public bool AddPattern(List<Vector3Int> indices)
    {

        //only add valid patterns
        if (indices == null) return false;
        if (indices[0] != Vector3Int.zero) return false;
        //Generate all the possible patterns with these parameters
        //rotate over Y . This will add 4 patterns rather than 1
        //you will have to sort out the patterntype, and probably replace it with a list
        _patterns.Add(new Pattern(new List<Vector3Int>(indices)));
        return true;
    }

    public bool AddPattern(Pattern newPattern)
    {
        if (newPattern.Indices == null) return false;
        if (newPattern.Indices[0] != Vector3Int.zero) return false;
        _patterns.Add(newPattern);
        return true;
    }

}
