﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class VoxelGrid : MonoBehaviour
{
    #region Public fields

    public Vector3Int GridSize;
    public Voxel[,,] Voxels;
    public Corner[,,] Corners;
    public Face[][,,] Faces = new Face[3][,,];
    public Edge[][,,] Edges = new Edge[3][,,];
    public Vector3 Origin;
    public Vector3 Corner;
    public float VoxelSize { get; private set; }

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor for a basic <see cref="VoxelGrid"/>
    /// </summary>
    /// <param name="size">Size of the grid</param>
    /// <param name="origin">Origin of the grid</param>
    /// <param name="voxelSize">The size of each <see cref="Voxel"/></param>
    public VoxelGrid(Vector3Int size, Vector3 origin, float voxelSize)
    {
        GridSize = size;
        Origin = origin;
        VoxelSize = voxelSize;

        Voxels = new Voxel[GridSize.x, GridSize.y, GridSize.z];

        for (int x = 0; x < GridSize.x; x++)
        {
            for (int y = 0; y < GridSize.y; y++)
            {
                for (int z = 0; z < GridSize.z; z++)
                {
                    Voxels[x, y, z] = new Voxel(
                        new Vector3Int(x, y, z),
                        this,
                        0.96f);
                }
            }
        }

        MakeFaces();
        MakeCorners();
        MakeEdges();
    }

    //06 Create the constructor for the GraphVoxel grid, based on an image
    /// <summary>
    /// Constructs a <see cref="VoxelGrid"/> with <see cref="GraphVoxel"/> from an image
    /// </summary>
    /// <param name="source">The source <see cref="Texture2D"/></param>
    /// <param name="height">The height of the <see cref="VoxelGrid"/> to be constructed</param>
    /// <param name="origin">Origin vector of the grid</param>
    /// <param name="voxelSize">The size of each <see cref="Voxel"/></param>
    public VoxelGrid(Texture2D source, int height, Vector3 origin, float voxelSize)
    {
        //07 Read grid dimensions in X and Z from image
        GridSize = new Vector3Int(source.width, height, source.height);

        Origin = origin;
        VoxelSize = voxelSize;

        Voxels = new Voxel[GridSize.x, GridSize.y, GridSize.z];

        for (int x = 0; x < GridSize.x; x++)
        {
            for (int y = 0; y < GridSize.y; y++)
            {
                for (int z = 0; z < GridSize.z; z++)
                {
                    Voxels[x, y, z] = new GraphVoxel(new Vector3Int(x, y, z), this, 1f, 0.96f);
                }
            }
        }

        //08 Add make Faces, Corners and Edges
        MakeFaces();
        MakeCorners();
        MakeEdges();
    }
    #endregion

    #region Grid elements constructors

    /// <summary>
    /// Creates the Faces of each <see cref="Voxel"/>
    /// </summary>
    private void MakeFaces()
    {
        // make faces
        Faces[0] = new Face[GridSize.x + 1, GridSize.y, GridSize.z];

        for (int x = 0; x < GridSize.x + 1; x++)
            for (int y = 0; y < GridSize.y; y++)
                for (int z = 0; z < GridSize.z; z++)
                {
                    Faces[0][x, y, z] = new Face(x, y, z, Axis.X, this);
                }

        Faces[1] = new Face[GridSize.x, GridSize.y + 1, GridSize.z];

        for (int x = 0; x < GridSize.x; x++)
            for (int y = 0; y < GridSize.y + 1; y++)
                for (int z = 0; z < GridSize.z; z++)
                {
                    Faces[1][x, y, z] = new Face(x, y, z, Axis.Y, this);
                }

        Faces[2] = new Face[GridSize.x, GridSize.y, GridSize.z + 1];

        for (int x = 0; x < GridSize.x; x++)
            for (int y = 0; y < GridSize.y; y++)
                for (int z = 0; z < GridSize.z + 1; z++)
                {
                    Faces[2][x, y, z] = new Face(x, y, z, Axis.Z, this);
                }
    }

    /// <summary>
    /// Creates the Corners of each Voxel
    /// </summary>
    private void MakeCorners()
    {
        Corner = new Vector3(Origin.x - VoxelSize / 2, Origin.y - VoxelSize / 2, Origin.z - VoxelSize / 2);

        Corners = new Corner[GridSize.x + 1, GridSize.y + 1, GridSize.z + 1];

        for (int x = 0; x < GridSize.x + 1; x++)
            for (int y = 0; y < GridSize.y + 1; y++)
                for (int z = 0; z < GridSize.z + 1; z++)
                {
                    Corners[x, y, z] = new Corner(new Vector3Int(x, y, z), this);
                }
    }

    /// <summary>
    /// Creates the Edges of each Voxel
    /// </summary>
    private void MakeEdges()
    {
        Edges[2] = new Edge[GridSize.x + 1, GridSize.y + 1, GridSize.z];

        for (int x = 0; x < GridSize.x + 1; x++)
            for (int y = 0; y < GridSize.y + 1; y++)
                for (int z = 0; z < GridSize.z; z++)
                {
                    Edges[2][x, y, z] = new Edge(x, y, z, Axis.Z, this);
                }

        Edges[0] = new Edge[GridSize.x, GridSize.y + 1, GridSize.z + 1];

        for (int x = 0; x < GridSize.x; x++)
            for (int y = 0; y < GridSize.y + 1; y++)
                for (int z = 0; z < GridSize.z + 1; z++)
                {
                    Edges[0][x, y, z] = new Edge(x, y, z, Axis.X, this);
                }

        Edges[1] = new Edge[GridSize.x + 1, GridSize.y, GridSize.z + 1];

        for (int x = 0; x < GridSize.x + 1; x++)
            for (int y = 0; y < GridSize.y; y++)
                for (int z = 0; z < GridSize.z + 1; z++)
                {
                    Edges[1][x, y, z] = new Edge(x, y, z, Axis.Y, this);
                }
    }

    #endregion

    #region Grid operations
    //12 Create method to read states from images
    /// <summary>
    /// Sets the states of each <see cref="Voxel"/> based on a <see cref="Texture2D"/>
    /// </summary>
    /// <param name="source">The source image</param>
    public void SetStatesFromImage(Texture2D source)
    {
        //13 Start from X and Z
        for (int x = 0; x < GridSize.x; x++)
        {
            for (int z = 0; z < GridSize.z; z++)
            {
                //14 Read pixel from image on location
                Color pixel = source.GetPixel(x, z);

                //15 Define a float value from the average of each channel (0 = black, 1 = white)
                float avgColor = 1 - (pixel.r + pixel.g + pixel.b) / 3f;

                //16 Start iteration on Y coordinate
                for (int y = 0; y < GridSize.y; y++)
                {


                    //17 Get Voxel on Coordinate as GraphVoxel
                    GraphVoxel voxel = (GraphVoxel)Voxels[x, y, z];

                    //20 Calculate state based on height, decreasing as it goes up
                    float state = avgColor ;

                    //21 Set state on GraphVoxel
                    voxel.SetState(state);
                }
            }
        }

        ////5.3 遍历
        //public void AddFloorblock()
        //{
        //    //13 Start from X and Z
        //    for (int x = 0; x < GridSize.x; x++)
        //    {
        //        for (int z = 0; z < GridSize.z; z++)
        //        {
        //            //14 Read pixel from image on location
        //            Color pixel = source.GetPixel(x, z);

        //            //15 Define a float value from the average of each channel (0 = black, 1 = white)
        //            float avgColor = 1 - (pixel.r + pixel.g + pixel.b) / 3f;

        //            //16 Start iteration on Y coordinate
        //            for (int y = 0; y < GridSize.y; y++)
        //            {


        //                //17 Get Voxel on Coordinate as GraphVoxel
        //                GraphVoxel voxel = (GraphVoxel)Voxels[x, y, z];

        //                //20 Calculate state based on height, decreasing as it goes up
        //                float state = avgColor;

        //                //21 Set state on GraphVoxel
        //                voxel.SetState(state);
        //            }
        //        }
        //    }
        //}


        //32 Deactivate voxels that are not adjacent to the obstacle
        foreach (GraphVoxel voxel in Voxels)
        {
            //33 Get the neighbours of this voxel
            var neighbours = voxel.GetFaceNeighbours().Select(n => (GraphVoxel)n);

            //34 If voxel is obstacle, activate it
            if (voxel.Isactive)
            {
                voxel.ActivateVoxel(true);
            }
            //35 If it is not obstacle, but one of its neighbours is, activate it
            //else if (neighbours.Any(n => n.Isactive))
            //{
            //    voxel.ActivateVoxel(true);

            //    //37 Also activate its neighbours, adding a second layer
            //    foreach (var neighbour in neighbours)
            //    {
            //        neighbour.ActivateVoxel(true);
            //    }
            //}
            //36 Deactivate every other voxel
            else
            {
                voxel.ActivateVoxel(false);
            }
        }
    }


    /// <summary>
    /// Get the Faces of the <see cref="VoxelGrid"/>
    /// </summary>
    /// <returns>All the faces</returns>
    public IEnumerable<Face> GetFaces()
    {
        for (int n = 0; n < 3; n++)
        {
            int xSize = Faces[n].GetLength(0);
            int ySize = Faces[n].GetLength(1);
            int zSize = Faces[n].GetLength(2);

            for (int x = 0; x < xSize; x++)
                for (int y = 0; y < ySize; y++)
                    for (int z = 0; z < zSize; z++)
                    {
                        yield return Faces[n][x, y, z];
                    }
        }
    }

    /// <summary>
    /// Get the Voxels of the <see cref="VoxelGrid"/>
    /// </summary>
    /// <returns>All the Voxels</returns>
    public IEnumerable<Voxel> GetVoxels()
    {
        for (int x = 0; x < GridSize.x; x++)
            for (int y = 0; y < GridSize.y; y++)
                for (int z = 0; z < GridSize.z; z++)
                {
                    yield return Voxels[x, y, z];
                }
    }

    /// <summary>
    /// Get the Corners of the <see cref="VoxelGrid"/>
    /// </summary>
    /// <returns>All the Corners</returns>
    public IEnumerable<Corner> GetCorners()
    {
        for (int x = 0; x < GridSize.x + 1; x++)
            for (int y = 0; y < GridSize.y + 1; y++)
                for (int z = 0; z < GridSize.z + 1; z++)
                {
                    yield return Corners[x, y, z];
                }
    }

    /// <summary>
    /// Get the Edges of the <see cref="VoxelGrid"/>
    /// </summary>
    /// <returns>All the edges</returns>
    public IEnumerable<Edge> GetEdges()
    {
        for (int n = 0; n < 3; n++)
        {
            int xSize = Edges[n].GetLength(0);
            int ySize = Edges[n].GetLength(1);
            int zSize = Edges[n].GetLength(2);

            for (int x = 0; x < xSize; x++)
                for (int y = 0; y < ySize; y++)
                    for (int z = 0; z < zSize; z++)
                    {
                        yield return Edges[n][x, y, z];
                    }
        }
    }

    #endregion
    //ljw

    private Dictionary<PatternType, GameObject> _goPatternPrefabs;
    public Dictionary<PatternType, GameObject> GOPatternPrefabs
    {
        get
        {
            if (_goPatternPrefabs == null)
            {
                _goPatternPrefabs = new Dictionary<PatternType, GameObject>();
                _goPatternPrefabs.Add(PatternType.PatternA, Resources.Load("Prefabs/1000") as GameObject);
                _goPatternPrefabs.Add(PatternType.PatternB, Resources.Load("Prefabs/800") as GameObject);

            }
            return _goPatternPrefabs;
        }
    }

    //ljw define floorvoxels

    //public List<Voxel> WallVoxels;
    //public List<Voxel> FloorVoxels;
    //public void AssignFloorWallVoxels()
    //{
    //    WallVoxels = new List<Voxel>();
    //    FloorVoxels = new List<Voxel>();

    //    foreach (var voxel in GetVoxels().Where(v => v.Status != VoxelState.Dead))
    //    {
    //        if (voxel.IsFloorVoxel()) FloorVoxels.Add(voxel);
    //    }
    //}


    //block foundation
    private List<Block> _blocks = new List<Block>();
    private PatternType _currentPattern = PatternType.PatternA;
    private List<Block> _currentBlocks => _blocks.Where(b => b.State != BlockState.Placed).ToList();

    #region Block functionality
    /// <summary>
    /// Temporary add a block to the grid. To confirm the block at it's current position, use the TryAddCurrentBlocksToGrid function
    /// </summary>
    /// <param name="anchor">The voxel where the pattern will start building from index(0,0,0) in the pattern</param>
    /// <param name="rotation">The rotation for the current block. This will be rounded to the nearest x,y or z axis</param>
    public void AddBlock(Vector3Int anchor, Quaternion rotation) => _blocks.Add(new Block(_currentPattern, anchor, rotation, this));

    /// <summary>
    /// Try to add the blocks that are currently pending to the grids
    /// </summary>
    /// <returns>true if the function managed to place all the current blocks. False in all other cases</returns>
    public bool TryAddCurrentBlocksToGrid()
    {
        if (_currentBlocks == null || _currentBlocks.Count == 0)
        {
            Debug.LogWarning("No blocks to add");
            return false;
        }
        if (_currentBlocks.Count(b => b.State != BlockState.Valid) > 0)
        {
            //if we use $ in front of ", variables can be added inline between {} when defining a string
            Debug.LogWarning($"{_currentBlocks.Count(b => b.State != BlockState.Valid)} blocks could not be place because their position is not valid");
            return false;
        }
        int counter = 0;
        //Keep adding blocks to the grid untill all the pending blocks are added
        while (_currentBlocks.Count > 0)
        {
            _currentBlocks.First().ActivateVoxels();
            counter++;
        }
        Debug.Log($"Added {counter} blocks to the grid");
        return true;
    }

    /// <summary>
    /// Remove all pending blocks from the grid
    /// </summary>
    //public void PurgeUnplacedBlocks()
    //{
    //    _blocks.RemoveAll(b => b.State != BlockState.Placed);
    //}

    //public void PurgeAllBlocks()
    //{
    //    foreach (var block in _blocks)
    //    {
    //        block.DestroyBlock();
    //    }
    //    _blocks = new List<Block>();
    //}

    /// <summary>
    /// Set a     PatternType based on all the possible patterns in te PatternType Enum.
    /// </summary>
    public void SetRandomType()
    {
        PatternType[] values = System.Enum.GetValues(typeof(PatternType)).Cast<PatternType>().ToArray();
        _currentPattern = (PatternType)values[Random.Range(0, values.Length)];
    }
    public void SetFloorType()
    {
        PatternType[] values = System.Enum.GetValues(typeof(PatternType)).Cast<PatternType>().ToArray();
        _currentPattern = (PatternType)values[0];
    }
    public Voxel GetVoxelByIndex(Vector3Int index) => Voxels[index.x, index.y, index.z];
    public void PurgeUnplacedBlocks()
    {
        _blocks.RemoveAll(b => b.State != BlockState.Placed);
    }

    #endregion


}
