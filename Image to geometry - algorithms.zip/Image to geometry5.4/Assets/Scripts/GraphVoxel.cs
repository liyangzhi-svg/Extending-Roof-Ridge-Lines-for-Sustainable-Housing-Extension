﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Create GraphVoxel, inherit from Voxel --- FROM David RC4_M1_C3
public class GraphVoxel : Voxel
{
    // Create Regions --- FROM David RC4_M1_C3
    #region Private fields

    // Create private _state float --- FROM David RC4_M1_C3
    private float _state;

    #endregion

    #region Public fields

    // Create Isactive variable --- FROM David RC4_M1_C3
    public bool Isactive;

    //LJW
    public int A = 0;



    #endregion

    #region Constructors

    // Create GraphVoxel constructor--- FROM David RC4_M1_C3
    /// <summary>
    /// Creates a <see cref="GraphVoxel"/>
    /// </summary>
    /// <param name="index">Index on the <see cref="VoxelGrid"/></param>
    /// <param name="voxelGrid">Grid the voxel is to be created at</param>
    /// <param name="state">Initial state the voxel should be set to</param>
    /// <param name="sizeFactor">Factor to scale the GameObject over the voxel size</param>
    public GraphVoxel(Vector3Int index, VoxelGrid voxelGrid, float state, float sizeFactor)
    {
        Index = index;
        _voxelGrid = voxelGrid;
        _size = _voxelGrid.VoxelSize;

        _state = state;

        _voxelGO = GameObject.CreatePrimitive(PrimitiveType.Cube);
        _voxelGO.transform.position = (_voxelGrid.Origin + Index) * _size;
        _voxelGO.transform.localScale *= _voxelGrid.VoxelSize * sizeFactor;
        _voxelGO.name = $"Voxel_{Index.x}_{Index.y}_{Index.z}";
        _voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/Basic");
    }

    #endregion

    #region Public methods

    // Create SetState method for the GraphVoxel
    /// <summary>
    /// Changes the state of the <see cref="GraphVoxel"/>, updating the material
    /// </summary>
    /// <param name="newState">The new state to be set</param>
    public void SetState(float newState)
    {
        //19 Set state field --- FROM David RC4_M1_C3
        _state = newState;

        //<param name="index">Index on the <see cref="VoxelGrid"/></param>
        int x = Index.x;
        int y = Index.y;
        int z = Index.z;
        var s = _voxelGrid.GridSize;


        // Set voxel as void if value is below threshold --- FROM David RC4_M1_C3
        if (_state <= 1 / _voxelGrid.GridSize.y)
        {
            // Read material and set
            _voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");

            // Set as active
            Isactive = false;

            // Create tag in Unity and set here
            _voxelGO.tag = "VoidVoxel";
        }
        // Set BLACK PIXELS as Wall
        if (_state >= 0.7)
        {
            //Read material and set
            _voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/Wall");

            // Set as active
            Isactive = true;

            //Create tag in Unity and set
            _voxelGO.tag = "Wall";
        }
        // Set y == 0 voxels as floor
        if (y == 0)
        {
            // Read material and set
            _voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/Floor");

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            _voxelGO.tag = "Floor";
        }

        // Set dark gray pixels as roof in 3M
        if (y == 14 && _state >= 0.58)
        {
            // Read material and set
            _voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/DARK GRAY");

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            _voxelGO.tag = "Roof";
        }
        // Set mid gray pixels as roof in 2M
        if (y == 9 && _state >= 0.39 && _state < 0.58)
        {
            // Read material and set
            _voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/MID GRAY");

            // Set as active
            Isactive = true;

            // Create tag in Unity and set
            _voxelGO.tag = "Roof";
        }


    }


    #endregion
}