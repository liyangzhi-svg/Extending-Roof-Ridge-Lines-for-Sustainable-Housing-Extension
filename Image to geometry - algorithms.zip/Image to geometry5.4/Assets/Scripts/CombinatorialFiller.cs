using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombinatorialFiller : MonoBehaviour
{
    //LJW ����
    private int _RandomCount_x = 0;
    private int _RandomCount = 0;
    private int _RandomCount_z = 5;
    private int _RandomCount_y = 0;
    private float _voxelSize = 0.95f;
    private int _voxelOffset = 2;
    private int _triesPerIteration = 10;

    private int _iterations = 30;

    private int _tryCounter = 0;
    private int _iterationCounter = 0;

    private bool generating = false;
    private int _seed = 0;

    private List<int> test = new List<int>();

    private Dictionary<int, float> _efficiencies = new Dictionary<int, float>();
    private List<int> orderedEfficiencyIndex = new List<int>();
    private VoxelGrid _voxelGrid;
    private CombinatorialFiller _combinatorialFiller;

    public List<Voxel> _FloorVoxels;
    public List<Voxel> _WallVoxels;
    public List<Voxel> _neighbours = new List<Voxel>();
    Texture2D _sourceImage;


    public void Start()
    {

        // Read Image from resources--- FROM David RC4_M1_C3
        _sourceImage = Resources.Load<Texture2D>("Data/P2P");

        // Create grid from image--- FROM David RC4_M1_C3
        _voxelGrid = new VoxelGrid(_sourceImage, 15, transform.position, 1f);


    }
    public void ReadImage()
    {
        _voxelGrid.SetStatesFromImage(_sourceImage);
    }


    public void Update()
    {

        if (Input.GetKeyDown("space"))
        {
            //TryAddRandomBlock();

            if (!generating)
            {
                generating = true;
                Debug.Log("40");
                PlaceStep();
            }
            else
            {
                generating = false;
                StopAllCoroutines();
            }
        }

        if (Input.GetKeyDown("w"))
        {
            //TryAddRandomBlock();

            if (!generating)
            {
                generating = true;
                Debug.Log("www");
                PlaceWallStep();
            }
            else
            {
                generating = false;
                StopAllCoroutines();
            }
        }

        if (Input.GetKeyDown("r"))
        {
            //TryAddRandomBlock();

            if (!generating)
            {
                generating = true;
                Debug.Log("roof");
                PlaceRoofStep();
            }
            else
            {
                generating = false;
                StopAllCoroutines();
            }
        }
    }

    Vector3Int RandomFloorIndex()
    {
        //int x = Random.Range(0, 5) * 5;


        if (_RandomCount_x < 60)
        {
            Vector3Int Floor3Int = new Vector3Int(_RandomCount_x + 2, 0, _RandomCount_z - 3);
            _RandomCount_x += 1;
            return Floor3Int;
        }
        if (_RandomCount_z < 60)
        {
            _RandomCount_z += 1;
            _RandomCount_x = 0;
            Vector3Int Floor3Int = new Vector3Int(_RandomCount_x + 2, 0, _RandomCount_z - 3);
            return Floor3Int;
        }
        Debug.Log("RandomFloorIndex_over");
        Vector3Int over = new Vector3Int(_RandomCount_x, 0, _RandomCount_z);
        return over;

        //Vector3Int Floor3Int = new Vector3Int(_RandomCount_x, 2, 10);
        //return Floor3Int;
    }

    Vector3Int RandomWallIndex(int x, int y, int z)
    {
        //int x = Random.Range(0, 5) * 5;


        //if (_RandomCount_x < 60)
        //{
        //    Vector3Int Floor3Int = new Vector3Int(_RandomCount_x + 2, _RandomCount_y, _RandomCount_z - 3);
        //    _RandomCount_x += 1;
        //    return Floor3Int;
        //}
        //if (_RandomCount_z < 60)
        //{
        //    _RandomCount_z += 1;
        //    _RandomCount_x = 0;
        //    Vector3Int Floor3Int = new Vector3Int(_RandomCount_x + 2, _RandomCount_y, _RandomCount_z - 3);
        //    return Floor3Int;
        //}
        //if (_RandomCount_y < 15)
        //{
        //    _RandomCount_y += 5;
        //    _RandomCount_x = 0;
        //    _RandomCount_z = 0;
        //    Vector3Int Floor3Int = new Vector3Int(_RandomCount_x + 2, _RandomCount_y, _RandomCount_z - 3);
        //    return Floor3Int;
        //}
        Debug.Log("RandomFloorIndex_over");
        Vector3Int over = new Vector3Int(x, y, z);
        return over;

        //Vector3Int Floor3Int = new Vector3Int(_RandomCount_x, 2, 10);
        //return Floor3Int;
    }

    Vector3Int RandomRoofIndex(int x, int y, int z)
    {

        Debug.Log("RandomFloorIndex_over");
        Vector3Int over = new Vector3Int(x, y, z);
        return over;
    }
    Quaternion RandomFloorRotation()
    {
        int x = Random.Range(0, 4) * 90;
        int y = Random.Range(0, 4) * 90;
        int z = Random.Range(0, 4) * 90;
        return Quaternion.Euler(90, 0, 0);
    }

    Quaternion RandomWallRotation()
    {
        int x = Random.Range(0, 4) * 90;
        int y = Random.Range(0, 4) * 90;
        int z = Random.Range(0, 4) * 90;
        return Quaternion.Euler(0, y, 0);
    }

    Quaternion RandomRoofRotation()
    {
        return Quaternion.Euler(90, 0, 0);
    }
    private bool TryAddFloorBlock()
    {
        _voxelGrid.SetFloorType();
        Debug.Log("66");
        _voxelGrid.AddBlock(RandomFloorIndex(), RandomFloorRotation());
        bool blockAdded = _voxelGrid.TryAddCurrentBlocksToGrid();
        //Debug.Log("HEllo");
        _voxelGrid.PurgeUnplacedBlocks();
        return blockAdded;
    }


    private bool TryAddWallBlock(int x, int y, int z)
    {
        _voxelGrid.SetFloorType();
        Debug.Log("88");
        _voxelGrid.AddBlock(RandomWallIndex(x, y, z), RandomWallRotation());
        bool blockAdded = _voxelGrid.TryAddCurrentBlocksToGrid();
        //Debug.Log("HEllo");
        _voxelGrid.PurgeUnplacedBlocks();
        return blockAdded;
    }

    private bool TryAddRoofBlock(int x, int y, int z)
    {
        _voxelGrid.SetFloorType();
        Debug.Log("99");
        _voxelGrid.AddBlock(RandomRoofIndex(x, y, z), RandomRoofRotation());
        bool blockAdded = _voxelGrid.TryAddCurrentBlocksToGrid();
        //Debug.Log("HEllo");
        _voxelGrid.PurgeUnplacedBlocks();
        return blockAdded;
    }


    private void PlaceStep()
    {
        /// _grid.PurgeAllBlocks();
        _tryCounter = 0;
        //LMZ   ����while�ڽ���ѭ���󣬲Ż�����һ��block
        //TryAddFloorBlock();

        for (int x = 0; x < _voxelGrid.GridSize.x; x++)
        {
            for (int y = 0; y < 3; y++)
            {
                for (int z = 0; z < _voxelGrid.GridSize.z; z++)
                {


                    if (_voxelGrid.Voxels[x, y, z]._voxelGO.tag == "Floor" && _voxelGrid.Voxels[x, y, z].IsActive && _voxelGrid.Voxels[x, y, z].Status != VoxelState.Available)
                    {
                        Debug.Log("23333");
                        TryAddFloorBlock();
                        _voxelGrid.Voxels[x, y, z].IsActive = false;
                        _voxelGrid.Voxels[x, y, z]._voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");


                    }


                }
            }
        }
    }




    private void PlaceWallStep()
    {
        /// _grid.PurgeAllBlocks();
        _tryCounter = 0;
        //LMZ   ����while�ڽ���ѭ���󣬲Ż�����һ��block
        //TryAddFloorBlock();

        for (int x = 0; x < _voxelGrid.GridSize.x; x++)
        {
            for (int y = 0; y < _voxelGrid.GridSize.y; y++)
            {
                for (int z = 0; z < _voxelGrid.GridSize.z; z++)
                {

                    if (_voxelGrid.Voxels[x, y, z]._voxelGO.tag == "Wall" && _voxelGrid.Voxels[x, y, z].IsActive)
                    {
                        Debug.Log("66666");
                        TryAddWallBlock(x, y, z);
                        //_voxelGrid.Voxels[x, y, z].IsActive = false;
                        _voxelGrid.Voxels[x, y, z]._voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");


                    }

                }
            }
        }

        //while (_tryCounter < _triesPerIteration)
        //{
        //    Debug.Log("80");
        //    TryAddFloorBlock();
        //    _tryCounter++;
        //}
        //while finish reset 0
        //_RandomCount = 5;
    }

    private void PlaceRoofStep()
    {
        /// _grid.PurgeAllBlocks();
        _tryCounter = 0;
        //LMZ   ����while�ڽ���ѭ���󣬲Ż�����һ��block
        //TryAddFloorBlock();

        for (int x = 0; x < _voxelGrid.GridSize.x; x++)
        {
            for (int y = 9; y < _voxelGrid.GridSize.y; y++)
            {
                for (int z = 0; z < _voxelGrid.GridSize.z; z++)
                {

                    if (_voxelGrid.Voxels[x, y, z]._voxelGO.tag == "Roof" && _voxelGrid.Voxels[x, y, z].IsActive)
                    {
                        Debug.Log("88888");
                        TryAddRoofBlock(x, y, z);
                        //_voxelGrid.Voxels[x, y, z].IsActive = false;
                        _voxelGrid.Voxels[x, y, z]._voxelGO.GetComponent<MeshRenderer>().material = Resources.Load<Material>("Materials/GV_Void");


                    }

                }
            }
        }
    }
}