using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public enum BlockState { Valid = 0, Intersecting = 1, OutOfBounds = 1, Placed = 2 }
public class Block 
{
    public List<Voxel> Voxels;

    public PatternType Type;
    private Pattern _pattern => PatternManager.GetPatternByType(Type);
    private VoxelGrid _grid;
    private GameObject _goBlock;

    public Vector3Int Anchor;
    public Quaternion Rotation;
    private bool _placed = false;


    //01 define block

    /// <summary>
    /// Get the current state of the block. Can be Valid, Intersecting, OutOfBound or Placed
    /// </summary>
    public BlockState State
    {
        get
        {
            if (_placed) return BlockState.Placed;
            if (Voxels.Count < _pattern.Indices.Count) return BlockState.OutOfBounds;

            //LJW inter dead
            //if (Voxels.Count(v => v.Status != VoxelState.Available) > 0) return BlockState.Intersecting;
            return BlockState.Valid;
        }
    }

    public void CreateGOBlock()
    {
        _goBlock = GameObject.Instantiate(_grid.GOPatternPrefabs[Type], _grid.GetVoxelByIndex(Anchor).Centre, Rotation);
    }

    public bool ActivateVoxels()
    {
        if (State != BlockState.Valid)
        {
            Debug.LogWarning("Block can't be placed");
            return false;
        }
        //LJW COLOR

        Color randomCol = new Color(125,125,125);

        foreach (var voxel in Voxels)
        {
            voxel.Status = VoxelState.Alive;
            voxel.SetColor(randomCol);
        }
        Debug.LogWarning("goblock");
        CreateGOBlock();
        _placed = true;
        return true;
    }


    public void PositionPattern()
    {
        Voxels = new List<Voxel>();
        foreach (var index in _pattern.Indices)
        {
            if (Util.TryOrientIndex(index, Anchor, Rotation, _grid, out var newIndex))
            {
                Voxels.Add(_grid.Voxels[newIndex.x, newIndex.y, newIndex.z]);
            }
        }
    }

    public Block(PatternType type, Vector3Int anchor, Quaternion rotation, VoxelGrid grid)
    {
        Type = type;
        Anchor = anchor;
        Rotation = rotation;
        _grid = grid;


        PositionPattern();
    }






}
